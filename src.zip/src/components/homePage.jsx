import tree from '../images/tree.png';
import jarrah from '../images/ind_img2_jarrah.png';
import seal_1 from '../images/seal_1.png';
import design from '../images/design.png';
import marri from  '../images/Marri@2x.png';
import group_196 from '../images/sealxx.png';
import seal_3 from '../images/seal_3.png'
import seal_4 from '../images/seal_4.png';
import side from '../images/side_view.png';
import video from '../images/video_proto.png';
import golden from '../images/golden_btn.png';
import australia from '../images/Australia_G.png';
import gift from '../images/Gift_symbl.png';
import bee from '../images/bees.png';
import bees from '../images/beekeepers.png';

function HomePage() {
  return (
    <>
 
    <section className="mainbanner1">
        <div className="container">
            <div className="row">
                <div className="col-md-12 ">
                    <div className="inner">
                    <h1>The world’s rarest <br/> Jarrah honey</h1>
                    <button>DISCOVER</button>
                </div>
                </div>
            </div>
        </div>
    </section>
     <section className="main2">
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                     <img src={jarrah} class="img1" alt=""/> 
                    <img src={seal_1} class="img2" alt=""/>
                </div>
                <div className="col-md-6">
                    <div className="inner">
                        <h5>COLLECTION-LIMITED BATCH</h5>
                        <h3>Old-Growth Harvest Honey</h3>
                        <p>Organically harvested from ancient forests, home to trees over 300 years old, each jar is a
                            pure reflection of its rare and unique origins.</p>
                        <button>DISCOVER</button>
                    </div>

                </div>
            </div>
        </div>
        <div>
             <img src={design} className="sec2img" alt=""/> 
        </div>
    </section>
    <section className="main3">
        <div className="container">
            <div className="row">

                <div className="col-md-12">
                    <div className="inner">
                        <h5>Collection - SMALL BATCH</h5>
                        <h3>Premium Harvest Honey</h3>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="inner2">
                        <div>
                            <h4 className="box1"></h4>
                            <img src={marri} alt="" class="img1"/>
                            <img src={group_196} alt="" class="img2a"/>
                        </div>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="inner2">
                        <div>
                            <h4 className="box2"></h4>
                            <img src={marri} alt="" class="img2"/>
                            <img src={seal_3} alt="" class="img2b"/>
                        </div>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="inner2">
                        <div>
                            <h4 className="box3"></h4>
                            <img src={marri} alt="" class="img3"/>
                            <img src={seal_4} alt="" class="img2c"/>
                        </div>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="inner3">
                        <h6>JARRAH</h6>
                        <p>Date <br/>
                            Chestnut <br/>
                            Nutmeg</p>
                        <button className="btn btn1">LEARN MORE</button>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="inner3">
                        <h6>MARRI</h6>
                        <p>Fruit-forward
                            Confectionary <br/>
                            Delicate raisin-richness</p>
                        <button className="btn btn2">LEARN MORE</button>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="inner3">
                        <h6>YARRI</h6>
                        <p>Molasses <br/>
                            Burnt caramel <br/>
                            Bush blossom</p>
                        <button className="btn btn3">LEARN MORE</button>
                    </div>
                </div>

                <div className="row bor">
                    <div className="col-md-6">
                        <div className="inner4">
                            <h5>conservation and exclusivity</h5>
                            <h3>Forest Age Rating</h3>
                            <p>Our unique Forest Age Rating (FAR) system is a testament to our commitment to quality,
                                rarity,
                                and the preservation of nature. This system categorises our honey based on the age of
                                the
                                forests from which it is sourced, highlighting the exclusivity as well as the
                                antibacterial
                                activity of the honey.

                                Old-Growth Collection honey is sourced from forests that are 300 years and older and has
                                a FAR
                                of 300Y+.

                                Premium Harvest Collection honey is sourced from forests that are 200 years and older
                                and has a
                                FAR of 200Y+.</p>
                        </div>
                    </div>

                    <div className="col-md-6">
                        <img src={side} alt=""/>
                    </div>
                </div>
            </div>
            </div>


    </section>
    <section className="main4">
        <div className="container">
            <div className="row">
                <div className="col-md-12 text">
                    <h3>Visit the forests of Heirloom Honey</h3>
                </div>
            </div>
        </div>

        <div className="col-md-12 image">
            <div class="inner">
            <img src={video} alt="" class="img1"/>
            <img src={golden} alt="" class="img2"/>
        </div>
        </div>
        <div className="container">

            <div className="row">
                <div className="col-md-12">
                    <div className="inner1">
                        <h5>A REASON FOR GIFTING</h5>
                        <h3>Limited Edition Luxury</h3>
                    </div>

                </div>
                <div className="col-md-4">
                    <div className="inner inner2">
                        <h6>RARITY</h6>
                        <img src={australia} alt="" class="imgs"/>
                        <p>Each prized jar is a symbol of exclusivity and craftsmanship, a delicacy that whispers tales
                            of ancient forests and vibrant blossoms.</p>

                    </div>

                </div>
                <div className="col-md-4">
                    <div className="inner inner3">
                        <h6>PERSONAL GIFTING</h6>
                        <img src={gift} alt="" class="imgs"/>
                        <p>Delight your loved ones with a gift that transcends ordinary gestures. Our rare honey is a
                            statement of sophistication and thoughtfulness.</p>

                    </div>

                </div>
                <div className="col-md-4">
                    <div className="inner inner4">
                        <h6>CORPORATE GIFTING</h6>
                        <img src={gift} alt="" class="imgs"/>
                        <p>Elevate your business relationships with a gift that is as rare and exceptional as the
                            partnerships you value.</p>

                    </div>

                </div>
            </div>
        </div>
    </section>
    <section className="main5">
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                    <div className="inner1">
                        <img src={tree} alt=""/>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="inner2">
                        <h5>LOCATION</h5>
                        <h3>Ancient Forests</h3>
                        <p>In a pristine corner of Western Australia, free from chemicals and untouched from the rest of
                            the world, lives a dense, ancient forest with towering trees.</p>
                        <button>OUR STORY</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section className="main6">
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                    <div className="inner1">
                        <h5>SCIENCE AND TASTE</h5>
                        <h3>Nature in Harmony</h3>
                        <p>The nectar from the Jarrah flower produces one of the world's most premier honeys. The
                            unmatched health benefits, coupled with a distinctive dark and earthy taste, make this
                            single origin honey highly sought-after.</p>
                        <button>OUR STORY</button>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="inner2">
                        <img src={bee} alt=""/>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section className="main7">
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                    <div className="inner1">
                        <img src={bees} alt=""/>
                    </div>
                </div>
                <div className="col-md-6">
                    <div className="inner2">
                        <h5>TRADITION AND HERITAGE</h5>
                        <h3>An Intuitive Craft</h3>
                        <p>The craft of beekeeping runs deep within the Spurge family. Intuitive knowledge has been
                            passed down from one generation to the next since 1850.</p>
                        <button>OUR STORY</button>

                    </div>
                </div>
            </div>
        </div>
    </section>
    </>
  );
}

export default HomePage;
