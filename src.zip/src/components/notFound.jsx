function NotFound() {
  return (
    <>
      <section className="body">Not Found</section>
    </>
  );
}

export default NotFound;
