function HomePage() {
  return (
    <>
      <section className="body">Contact Page</section>
    </>
  );
}

export default HomePage;
