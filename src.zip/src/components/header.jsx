function Header(){
    return(
        <>
         <header>
        <div className="container">
      <div className="row">
        <div className="col-md-4 inner1">
            <h5>COLLECTIONS</h5>
          </div>
          <div className="col-md-4 inner2h">
              <h3>HIERLOOM <br/> HONEY CO.<br/></h3>
          </div>
          <div className="col-md-4 inner3">
              <h5>OUR STORY</h5>
          </div>
      </div>  
    </div>
     
    </header>
        </>
    );
}

export default Header;