function HomePage() {
  return (
    <>
      <section className="body">About Page</section>
    </>
  );
}

export default HomePage;
