import React from 'react';

const fname= Isht;
const lname= Chawla;
const d= Date;
const t= TimeRanges;

function HelloWorld() {
    return (
        <>
        <h1>{`Hello My Name is${fname} ${lname}`} </h1>
              <p>the date is{d}</p>
              <p>the time is {t} </p>
        </>
    );
}
export default HelloWorld;