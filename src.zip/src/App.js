// import logo from './logo.svg';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';



import Home from './components/homePage';
import Harvest from './components/HarvestJara';
import Contact from './components/contact';
import NotFound from './components/notFound';
import Marry from './components/premiummarry'
import Premium from './components/premiumjara';
import Yarri from './components/premiumyarry';
import Header from './components/header'; 
import Story from './components/ourstory';

import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css';
import './index.css';

function App() {
  return (
    <>
      

      <Router>
        <div>
          <Header/>
          {/*  Create Slugs using Routes */}
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route path="/HarvestJara" element={<Harvest />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="*" element={<NotFound />} />
            <Route path="/premiumjara" element={<Premium/>}/>
            <Route path="/premiummarry" element={<Marry/>}/>
            <Route path="/ourstory" element={<Story/>}/>
            <Route path="/premiumyarry" element={<Yarri/>}/>
          
          </Routes>
        </div>
      </Router>


      
    </>
  );
}

export default App;
